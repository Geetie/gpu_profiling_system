cd /workspace
PYTHONPATH=/workspace:/workspace/mlsys-project-main:$PYTHONPATH python -m agent.agent_framework
